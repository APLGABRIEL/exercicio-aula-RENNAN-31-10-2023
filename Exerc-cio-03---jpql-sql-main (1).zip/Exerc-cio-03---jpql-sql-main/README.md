# Exerc-cio-03---jpql-sql

Criar um método JPQL   que receba uma string como parâmetro em seu repositório JPA, que retorne um Optional<Produto> por nome do produto;
Criar um método  SQL native que receba uma string como parâmetro  em seu repositório JPA, que retorne um Optional<Produto> por nome do produto;
Atividade individual;
Forma de entrega devera publica em seu GIT, e anexar o link do repositório como resposta da atividade;
Atividade para ser feito em sala, não será aceito entregas após esse horário;
Exercício vale 1.0 ponto na segunda nota;

Grupo:

https://github.com/vitoraranha2003 , https://github.com/lucaskgf , https://github.com/APLGABRIEL, https://github.com/ogabrielpontes , https://github.com/juanliira, https://github.com/nathanserrao
